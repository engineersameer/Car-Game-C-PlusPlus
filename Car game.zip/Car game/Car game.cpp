/*
Lets add some creativity in the game
$ : For adding bonus of 2 in the game
^ : Touching this will move the car 3 times downward
S : Touching this will put the car back in start line
E : Touching this will put the car back at the end line
*/
/*
#include <windows.h>

HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
SetConsoleTextAttribute(h,1);

1: blue
2: green
3: cyan
4: red
5: purple
6: yellow (dark)
7: default white
8: gray/grey
9: bright blue
10: bright green
11: bright cyan
12: bright red
13: pink/magenta
14: yellow
15: bright white
*/
/*
Sameer Tariq 22i_1512
Musab bin ubaid 22i_2708
*/
#include <iostream>
#include"Header.h"
#include<chrono>
#include<thread>
#include <Windows.h>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sstream>
#include <fstream>
#include <conio.h>
int main()
{
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(h, 11);


    // system("cls");
    string name;
    /* cout << "\n\n\n                     WElcome to the 'Car Race Game'           " << endl<<endl;
     cout << "                         PLAYER NAME : ";
    */
    cout << "\n\n\n";
    cout << "    #########################################################\n";
    cout << "    ##                                                     ##\n";
    cout << "    ##                                                    ##\n";
    cout << "    ##            Welcome to the 'Turbo Thrust'         ##\n";
    cout << "    ##                                                    ##\n";
    cout << "    ##                                                     ##\n";
    cout << "    #########################################################\n\n\n";
    cout << "                    Player name : ";
    SetConsoleTextAttribute(h, 15);
    cin >> name;
    system("cls");
label:
    graph** ptr = NULL;
    game g;
    g.setPlayer_name(name);
    while (1)
    {
        SetConsoleTextAttribute(h, 6);
        int temp_level = 0;//To check during the game either player has passed the level or no
        cout << "\n\n\n";
        cout << "    #############################################\n";
        cout << "    ##                                         ##\n";
        cout << "    ##      Select an option:                    ##\n";
        cout << "    ##                                         ##\n";
        cout << "    ##      1. Start Game Mannually              ##\n";
        cout << "    ##      2. Start  Game automatically         ##\n";
        cout << "    ##      3. Rules & Regulations               ##\n";
        cout << "    ##      4. Number of Game & Score            ##\n";
        cout << "    ##      5. controls                          ##\n";
        cout << "    ##      6. Exit                             ##\n";
        cout << "    ##                                           ##\n";
        cout << "    #############################################\n\n\n";
        SetConsoleTextAttribute(h, 14);
        cout << "             Option : ";
        int options;
        cin >> options;
        SetConsoleTextAttribute(h, 15);
        system("cls");
        switch (options)
        {
        case 1:
            while (1)
            {
                ptr = g.create_grid(g);
                g.print_grid(ptr, g, 1);

                while (1)
                {
                    char choice;
                    choice = _getch();
                    system("cls");
                    if (choice == 'q')
                    {
                        ptr = NULL;
                        g.level = 0;
                        g.index = 0;
                        g.protect = 0;
                        g.index = 1;
                        g.bost = 0;
                        g.check = 0;
                        g.set_score(0);
                        g.head = NULL;
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 6);
                        cout << "press 1 to continue" << endl;
                        int continu;
                        SetConsoleTextAttribute(h, 15);

                        cin >> continu;
                        if (continu == 1)
                        {
                            system("cls");
                        }
                        else
                        {
                            system("cls");
                        }
                        goto label;
                    }
                    else
                    {
                        temp_level = g.level;
                        ptr = g.move(choice, ptr, g);  //car moviing from one node to other in the graph
                        if (ptr == NULL)   //This condtion will executed when player will lost the game
                        {
                            HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                            SetConsoleTextAttribute(h, 11);
                            string line;
                            string key; //Name of player from the file
                            string value; // Highest score by player
                            ifstream file("record.txt");    //for taking each player score from file into the heap / tree 
                            if (!file.is_open())
                            {
                                cout << "Error opening file 'record.txt'" << endl;   //In case if file don not open
                                return 1;
                            }
                            while (getline(file, line))    //This is for making heap tree from the data that is stored in the file
                            {
                                istringstream is(line);
                                getline(is, key, ':');
                                getline(is, value);   //line part next to key is stored in the value
                                int temm = stoi(value); // converting into the integer
                                g.insertAndUpdate(temm);    ///Making tree by getting data from the file
                            }
                            g.insertAndUpdate(g.get_score());
                            cout << "Player name : " << name << endl;
                            cout << "Total Score : " << g.get_score() << endl;
                            cout << "Highest Score : " << g.getMax() << endl;
                            ofstream updateFile("record.txt", ios::app);
                            if (!updateFile.is_open())
                            {
                                cout << "Error opening file 'record.txt' for update" << endl; //In case if file don not open
                                return 1;
                            }
                            updateFile << name << ":" << g.get_score() << "\n";
                            updateFile.close();

                            cout << "Total bonus collected during the game : " << g.index - 1 << endl;   //as index increased by one at the end of bonus list function call
                            cout << "Do you want to see the details of bonuses you collected in this game    0- No    1- Yes" << endl;
                            SetConsoleTextAttribute(h, 15);
                            bool choice;
                            cin >> choice;
                            if (choice == 1)
                            {
                                g.print_bonus();
                            }
                            ptr = NULL;
                            g.level = 0;
                            g.protect = 0;
                            g.index = 1;
                            g.bost = 0;
                            g.check = 0;
                            g.setPlayer_name("");
                            g.head = NULL;
                            g.set_score(0);
                            SetConsoleTextAttribute(h, 6);
                            cout << "press 1 to continue" << endl;
                            SetConsoleTextAttribute(h, 15);
                            int continu;
                            cin >> continu;
                            if (continu == 1)
                            {
                                system("cls");
                            }
                            else
                            {
                                system("cls");
                            }
                            goto label;
                        }
                        if (temp_level == g.level)
                        {
                            g.print_grid(ptr, g, 1);
                        }
                        if (g.level > temp_level)  //this means that level has been passed in the game
                        {
                            temp_level++;
                            if (g.level <= 3)
                            {
                                ptr = NULL;
                                break;
                            }
                            if (g.level > 3)  //Means stll need more level to excecute
                            {
                                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                                SetConsoleTextAttribute(h, 11);
                                string line;
                                string key; //Name of player from the file
                                string value; // Highest score by player
                                ifstream file("record.txt");
                                if (!file.is_open())
                                {
                                    cout << "Error opening file 'record.txt'" << endl;
                                    return 1;
                                }
                                while (getline(file, line))    //This is for making heap tree from the data that is stored in the file
                                {
                                    istringstream is(line);
                                    getline(is, key, ':');
                                    getline(is, value);   //line part next to key is stored in the value
                                    int temm = stoi(value); // converting into the integer
                                    g.insertAndUpdate(temm);    ///Making tree by getting data from the file
                                }
                                g.insertAndUpdate(g.get_score());
                                cout << "Player name : " << name << endl;
                                cout << "Total Score : " << g.get_score() << endl;
                                cout << "Highest Score : " << g.getMax() << endl;
                                ofstream updateFile("record.txt", ios::app);   //For writing name of each player with its score in file
                                if (!updateFile.is_open())
                                {
                                    cout << "Error opening file 'record.txt' for update" << endl;  //In case if file dont open
                                    return 1;
                                }
                                updateFile << name << ":" << g.get_score() << "\n";
                                updateFile.close();
                                cout << "Total bonus collected during the game : " << g.index - 1 << endl;   //as index increased by one at the end of bonus list function call
                                cout << "Do you want to see the details of bonuses you collected in this game    0- No    1- Yes" << endl;
                                SetConsoleTextAttribute(h, 15);
                                bool choice;
                                cin >> choice;
                                if (choice == 1)
                                {
                                    g.print_bonus();
                                }
                                ptr = NULL;
                                g.level = 0;
                                g.protect = 0;
                                g.index = 1;
                                g.bost = 0;
                                g.check = 0;
                                g.setPlayer_name("");
                                g.head = NULL;
                                g.set_score(0);
                                SetConsoleTextAttribute(h, 6);
                                cout << "press 1 to continue" << endl;
                                SetConsoleTextAttribute(h, 15);
                                int continu;
                                cin >> continu;
                                if (continu == 1)
                                {
                                    system("cls");
                                }
                                else
                                {
                                    system("cls");
                                }
                                goto label;
                            }
                        }
                    }
                }
            }
            break;
        case 2:
        {
            g.automatic(g, ptr);
            HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
            SetConsoleTextAttribute(h, 11);
            string line;
            string key; //Name of player from the file
            string value; // Highest score by player
            ifstream file("record.txt");    //for taking each player score from file into the heap / tree 
            if (!file.is_open())
            {
                cout << "Error opening file 'record.txt'" << endl;   //In case if file don not open
                return 1;
            }
            while (getline(file, line))    //This is for making heap tree from the data that is stored in the file
            {
                istringstream is(line);
                getline(is, key, ':');
                getline(is, value);   //line part next to key is stored in the value
                int temm = stoi(value); // converting into the integer
                g.insertAndUpdate(temm);    ///Making tree by getting data from the file
            }
            g.insertAndUpdate(g.get_score());
            cout << "Player name : " << name << endl;
            cout << "Total Score : " << g.get_score() << endl;
            cout << "Highest Score : " << g.getMax() << endl;
            ofstream updateFile("record.txt", ios::app);
            if (!updateFile.is_open())
            {
                cout << "Error opening file 'record.txt' for update" << endl; //In case if file don not open
                return 1;
            }
            updateFile << name << ":" << g.get_score() << "\n";
            updateFile.close();

            cout << "Total bonus collected during the game : " << g.index - 1 << endl;   //as index increased by one at the end of bonus list function call
            cout << "Do you want to see the details of bonuses you collected in this game    0- No    1- Yes" << endl;
            SetConsoleTextAttribute(h, 15);
            bool choice;
            cin >> choice;
            if (choice == 1)
            {
                g.print_bonus();
            }
            ptr = NULL;
            g.level = 0;
            g.protect = 0;
            g.index = 1;
            g.bost = 0;
            g.check = 0;
            g.setPlayer_name("");
            g.head = NULL;
            g.set_score(0);
            SetConsoleTextAttribute(h, 6);
            cout << "press 1 to continue" << endl;
            SetConsoleTextAttribute(h, 15);
            int continu;
            cin >> continu;
            if (continu == 1)
            {
                system("cls");
            }
            else
            {
                system("cls");
            }
            goto label;
        }
        case 3:
            g.rules_regulation();
            goto label;
        case 4:
        {
            string line;
            string key; //Name of player from the file
            string value; // Highest score by player
            ifstream file("record.txt");

            if (!file.is_open()) {
                cout << "Error opening file 'record.txt'" << endl;
                return 1;
            }
            int num = 1;
            while (getline(file, line))
            {
                istringstream is(line);
                getline(is, key, ':');
                getline(is, value);   //line part next to key is stored in the value
                int temm = stoi(value); // converting into the integer
                cout << num << "- Player : " << key << "     Score : " << temm << endl;
                num++;
            }
            HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
            SetConsoleTextAttribute(h, 6);
            cout << "press 1 to continue" << endl;
            SetConsoleTextAttribute(h, 15);
            bool ask;
            cin >> ask;
            if (ask == 1)
            {
                system("cls");
            }
            else
            {
                system("cls");
            }
            goto label;

        }
        case 5:
            g.controls();
            goto label;
        case 6:
            return 0;

        default:
            exit(0);
            break;
        }
    }
    return 0;
}