/*
Sameer Tariq 22i_1512
Musab bin ubaid 22i_2708
*/
#pragma once
#include <iostream>
#include<chrono>
#include<thread>
#include <Windows.h>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sstream>
#include <fstream>
#include <conio.h>
using namespace std;
class bonus    //Node class for bonus
{
public:
    int num;
    char type;
    int score;
    int level;
    bonus* next;
    bonus* previous;
};
class Random_Obstacles   //Class for adding obstacles at random position 
{
    char* array;
    int front;
    int back;
    int size;
public:
    void set_size(int size)
    {
        this->size = size;
        array = new char[size];
        front = -1;
        back = -1;

    }
    void enqueue_r_obstacle(int x)
    {
        if (front == -1)  //As we know front will move only for the first time when something will add for the first time in the queue
        {
            front++;
        }
        if (back == size - 1) //As if n=5 then back need to be stop at 4th as we are dealing in array
        {
            cout << "Queue is already full " << endl;
        }
        else
        {
            back++;
            array[back] = x;
        }
    }
    char dequeue_r_obstacle()
    {
        //also add condition if we have only element in the queue than need to move back the front and rear after the first element has been poped
        if (front == -1 || front > back)  //This means Queue is empty  ( front> back ) yeh condition tb zrori agr is se niche wali condition ni lgani(front == back)
        {
            cout << "Queue is empty " << endl;
            return 'x';
        }
        else if (front == back)  //pop krte krte agr asi jga puhnch jae k ek e element queue me reh jae phr ager pop kre gy to queue khali hojae ga
        {
            front = back = -1; //Assining -1 to both after poping
            return 'x';
        }
        else  //condition if we have more than 1 element in the queue
        {
            front++;
            return array[front];
        }
    }
};

class Obstacles    //class for adding obstacles at fixed position
{
    char* array;
    int front;
    int back;
    int size;
public:
    void set_size(int size)
    {
        this->size = size;
        array = new char[size];
        front = -1;
        back = -1;
    }
    void enqueue_obstacle(int x)
    {
        if (front == -1)  //As we know front will move only for the first time when something will add for the first time in the queue
        {
            front++;
        }
        if (back == size - 1) //As if n=5 then back need to be stop at 4th as we are dealing in array
        {
            cout << "Queue is already full " << endl;
        }
        else
        {
            back++;
            array[back] = x;
        }
    }
    char dequeue_obstacle()
    {
        //also add condition if we have only element in the queue than need to move back the front and rear after the first element has been poped
        if (front == -1 || front > back)  //This means Queue is empty  ( front> back ) yeh condition tb zrori agr is se niche wali condition ni lgani(front == back)
        {
            cout << "Queue is empty " << endl;
            return 'x';
        }
        else if (front == back)  //pop krte krte agr asi jga puhnch jae k ek e element queue me reh jae phr ager pop kre gy to queue khali hojae ga
        {
            front = back = -1; //Assining -1 to both after poping
            return 'x';
        }
        else  //condition if we have more than 1 element in the queue
        {
            front++;
            return array[front];
        }
    }
};
class Powers_up    //class for adding powers up at fixed postion in the game
{
    char* array;
    int front;
    int back;
    int size;
public:
    void set_size(int size)
    {
        this->size = size;
        array = new char[size];
        front = -1;
        back = -1;

    }
    void enqueue_powers(int x)
    {
        if (front == -1)  //As we know front will move only for the first time when something will add for the first time in the queue
        {
            front++;
        }
        if (back == size - 1) //As if n=5 then back need to be stop at 4th as we are dealing in array
        {
            cout << "Queue is already full " << endl;
        }
        else
        {
            back++;
            array[back] = x;
        }
    }
    char dequeue_powers()
    {
        //also add condition if we have only element in the queue than need to move back the front and rear after the first element has been poped
        if (front == -1 || front > back)  //This means Queue is empty  ( front> back ) yeh condition tb zrori agr is se niche wali condition ni lgani(front == back)
        {
            cout << "Queue is empty " << endl;
            return 'x';
        }
        else if (front == back)  //pop krte krte agr asi jga puhnch jae k ek e element queue me reh jae phr ager pop kre gy to queue khali hojae ga
        {
            front = back = -1; //Assining -1 to both after poping
            return 'x';
        }
        else  //condition if we have more than 1 element in the queue
        {
            front++;
            return array[front];
        }
    }

};
class MaxHeapNode //class acting as a node for binary heap tree
{
public:
    int score;
    MaxHeapNode* left;
    MaxHeapNode* right;

    MaxHeapNode(int s)
    {
        this->score = s;
        this->left = NULL;
        this->right = NULL;

    }
};
class graph
{
public:
    char name;
    graph* left;
    graph* right;
    graph* up;
    graph* down;
};
class game
{
    MaxHeapNode* root;
    graph** array;
    int score = 0;
    int temp1, temp2, temp3, temp4 = 0;
    string player_name;
public:
    int check = 0;//This variable is for checking either the car if hits the obstacles for three times consectively
    bonus* head;
    static int bost;
    static int protect;
    static int index;
    int level = 1;
    Obstacles o;   //object of class obstacles 
    Powers_up p;   //object of class powers up
    Random_Obstacles r;
    void setPlayer_name(string name)  //setter
    {
        this->player_name = name;
    }
    string getPlayerName()  //getter
    {
        return player_name;
    }
    void set_score(int s)  //setter
    {
        this->score = s;
    }
    int get_score()  //getter
    {
        return score;
    }

    graph** create_grid(game& obj)
    {
        int a = 0;
        if (obj.level == 1)    //size of queue will be fixed according the level of the game
        {
            a = 20;
            o.set_size(81);
            p.set_size(81);
            r.set_size(81);
            for (int x = 0;x < 81;x++)
            {
                o.enqueue_obstacle('X');
                p.enqueue_powers('$');
                r.enqueue_r_obstacle('Y');
            }
        }
        else if (obj.level == 2)  //size of queue will be fixed according the level of the game
        {
            o.set_size(196);
            p.set_size(196);
            r.set_size(196);

            for (int x = 0;x < 196;x++)
            {
                o.enqueue_obstacle('X');
                p.enqueue_powers('$');
                r.enqueue_r_obstacle('Y');
            }
            a = 30;
        }
        else if (obj.level == 3)    //size of queue will be fixed according the level of the game
        {
            o.set_size(361);
            p.set_size(361);
            r.set_size(361);
            for (int x = 0;x < 361;x++)
            {
                o.enqueue_obstacle('X');
                p.enqueue_powers('$');
                r.enqueue_r_obstacle('Y');
            }
            a = 40;
        }
        this->array = new graph * [a];
        for (int i = 0; i < a; i++)
        {
            this->array[i] = new graph[a];
        }
        for (int i = 0; i < a; i++)
        {
            for (int j = 0; j < a; j++)
            {
                // You can initialize your graph nodes here if needed
                if (i == 0 || j == 0 || j == a - 1 || i == a - 1)
                {
                    if (i == 0)
                    {
                        array[i][j].name = '-';  // Initialize with a sample value
                        array[i][j].left = nullptr;
                        array[i][j].right = nullptr;
                        array[i][j].up = nullptr;
                        array[i][j].down = nullptr;
                    }
                    if (j == 0 && i != 0 || j == a - 1 && i != 0)
                    {
                        array[i][j].name = '|';  // Initialize with a sample value
                        array[i][j].left = nullptr;
                        array[i][j].right = nullptr;
                        array[i][j].up = nullptr;
                        array[i][j].down = nullptr;
                    }
                    if (j == a - 1)
                    {
                        array[i][j].name = '|';  // Initialize with a sample value
                        array[i][j].left = nullptr;
                        array[i][j].right = nullptr;
                        array[i][j].up = nullptr;
                        array[i][j].down = nullptr;
                    }
                    if (i == a - 1)
                    {
                        array[i][j].name = '-';  // Initialize with a sample value
                        array[i][j].left = nullptr;
                        array[i][j].right = nullptr;
                        array[i][j].up = nullptr;
                        array[i][j].down = nullptr;
                    }
                    if (i == 0 && j == a - 1)
                    {
                        array[i][j].name = '-';  // Initialize with a sample value
                        array[i][j].left = nullptr;
                        array[i][j].right = nullptr;
                        array[i][j].up = nullptr;
                        array[i][j].down = nullptr;
                    }
                }
                else
                {
                    if (obj.level == 1)
                    {
                        if (i % 3 == 0 && j % 3 == 0)
                        {
                            array[i][j].name = o.dequeue_obstacle();
                            array[i][j].left = nullptr;
                            array[i][j].right = nullptr;
                            array[i][j].up = nullptr;
                            array[i][j].down = nullptr;

                        }
                        else
                        {
                            if (temp1 >= 11)
                            {
                                array[i][j].name = p.dequeue_powers();  //Initializing by dequeuing some value from the queuw
                                array[i][j].left = nullptr;
                                array[i][j].right = nullptr;
                                array[i][j].up = nullptr;
                                array[i][j].down = nullptr;
                                temp1 = 0;
                            }
                            else
                            {
                                if (temp2 >= 20)
                                {
                                    array[i][j].name = '^';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp2 = 0;
                                }
                                else if (temp3 >= 35)
                                {
                                    array[i][j].name = 'S';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp3 = 0;
                                }
                                else if (temp4 >= 55)
                                {
                                    array[i][j].name = 'E';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp4 = 0;
                                }
                                else
                                {
                                    array[i][j].name = '.';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                }
                                temp3++;
                                temp2++;
                                temp4++;
                            }
                            temp1++;
                        }
                    }
                    else if (obj.level == 2)
                    {
                        //Initailizing with dequeuing the queue
                        if (i % 3 == 0 && j % 3 == 0)
                        {
                            array[i][j].name = o.dequeue_obstacle();
                            array[i][j].left = nullptr;
                            array[i][j].right = nullptr;
                            array[i][j].up = nullptr;
                            array[i][j].down = nullptr;

                        }
                        else
                        {
                            if (temp1 >= 11)
                            {
                                array[i][j].name = p.dequeue_powers();  // Initialize with a sample value
                                array[i][j].left = nullptr;
                                array[i][j].right = nullptr;
                                array[i][j].up = nullptr;
                                array[i][j].down = nullptr;
                                temp1 = 0;
                            }
                            else
                            {
                                if (temp2 >= 20)
                                {
                                    array[i][j].name = '^';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp2 = 0;
                                }
                                else if (temp3 >= 35)
                                {
                                    array[i][j].name = 'S';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp3 = 0;
                                }
                                else if (temp4 >= 55)
                                {
                                    array[i][j].name = 'E';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp4 = 0;
                                }
                                else
                                {
                                    array[i][j].name = '.';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                }
                                temp3++;
                                temp2++;
                                temp4++;
                            }
                            temp1++;
                        }
                    }
                    else if (obj.level == 3)
                    {
                        if (i % 3 == 0 && j % 3 == 0)
                        {
                            array[i][j].name = o.dequeue_obstacle();   //Initailizing with dewueuing the queue
                            array[i][j].left = nullptr;
                            array[i][j].right = nullptr;
                            array[i][j].up = nullptr;
                            array[i][j].down = nullptr;

                        }
                        else
                        {
                            if (temp1 >= 15)
                            {
                                array[i][j].name = p.dequeue_powers();  // Initialize with a sample value
                                array[i][j].left = nullptr;
                                array[i][j].right = nullptr;
                                array[i][j].up = nullptr;
                                array[i][j].down = nullptr;
                                temp1 = 0;
                            }
                            else
                            {
                                if (temp2 >= 20)
                                {
                                    array[i][j].name = '^';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp2 = 0;
                                }
                                else if (temp3 >= 35)
                                {
                                    array[i][j].name = 'S';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp3 = 0;
                                }
                                else if (temp4 >= 55)
                                {
                                    array[i][j].name = 'E';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                    temp4 = 0;
                                }
                                else
                                {
                                    array[i][j].name = '.';  // Initialize with a sample value
                                    array[i][j].left = nullptr;
                                    array[i][j].right = nullptr;
                                    array[i][j].up = nullptr;
                                    array[i][j].down = nullptr;
                                }
                                temp3++;
                                temp2++;
                                temp4++;
                            }
                            temp1++;
                        }
                    }

                }
                if (i == 1 && j == 1)
                {
                    array[i][j].name = '@';  // Initialize with a sample value
                    array[i][j].left = nullptr;
                    array[i][j].right = nullptr;
                    array[i][j].up = nullptr;
                    array[i][j].down = nullptr;

                }
                if (i == a - 2 && j == a - 2)
                {
                    array[i][j].name = '#';  // Initialize with a sample value
                    array[i][j].left = nullptr;
                    array[i][j].right = nullptr;
                    array[i][j].up = nullptr;
                    array[i][j].down = nullptr;

                }
            }
        }
        //Implementing the concept of graph at each node in the game grid
        //Now adding edges in the graph
        for (int x = 0;x < a;x++)
        {
            for (int y = 0;y < a;y++)
            {
                if (y - 1 >= 0)  //left
                {
                    array[x][y].left = &array[x][y - 1];
                }
                if (y + 1 <= a - 1)  // right
                {
                    array[x][y].right = &array[x][y + 1];
                }
                if (x - 1 >= 0)  //up
                {
                    array[x][y].up = &array[x - 1][y];
                }
                if (x + 1 <= a - 1)  //down
                {
                    array[x][y].down = &array[x + 1][y];
                }
            }
        }
        return array;
    }
    void print_grid(graph**& ptr, game& obj, int condition)
    {
        srand(static_cast<unsigned int>(time(0)));
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);   //library for adding colours/ themes in the game
        SetConsoleTextAttribute(h, 10);
        cout << "Level : ";
        SetConsoleTextAttribute(h, 15);
        cout << level;
        SetConsoleTextAttribute(h, 10);
        cout << "                   Score : ";
        SetConsoleTextAttribute(h, 15);
        cout << score << endl;
        int a = 0;
        if (obj.level == 1)    //setting grid size according to the level
        {
            a = 20;
        }
        else if (obj.level == 2)  //setting grid size according to the level
        {
            a = 30;
        }
        else if (obj.level == 3)   //setting grid size according to the level
        {
            a = 40;
        }
        if (condition == 1)
        {
            while (1)
            {
                bool chk = false;
                int x1 = 0, y1 = 0;
                if (obj.level == 1 && obj.bost % 7 == 0)   //This mode is adding randome obstacle in the queue after each interval
                {
                    x1 = rand() % 14 + 1;
                    y1 = rand() % 14 + 1;
                    if (ptr[x1][y1].name == '.')
                    {
                        ptr[x1][y1].name = r.dequeue_r_obstacle();
                    }
                }
                else if (obj.level == 2 && obj.bost % 8 == 0)   //This mode is adding randome obstacle in the queue after each interval
                {
                    x1 = rand() % 25 + 1;
                    y1 = rand() % 25 + 1;
                    if (ptr[x1][y1].name == '.')
                    {
                        ptr[x1][y1].name = r.dequeue_r_obstacle();
                    }
                }
                else if (obj.level == 3 && obj.bost % 9 == 0)  //This mode is adding randome obstacle in the queue after each interval
                {
                    x1 = rand() % 35 + 1;
                    y1 = rand() % 35 + 1;
                    if (ptr[x1][y1].name == '.')
                    {
                        ptr[x1][y1].name = r.dequeue_r_obstacle();
                    }
                }
                obj.bost++;
                break;
            }
        }

        for (int i = 0; i < a; i++)
        {
            for (int j = 0; j < a; j++)
            {
                if (ptr[i][j].name == '.')
                {
                    SetConsoleTextAttribute(h, 0);   //adding colours
                }
                else if (ptr[i][j].name == '|')
                {
                    SetConsoleTextAttribute(h, 14);   //black
                }
                else if (ptr[i][j].name == '-')
                {
                    SetConsoleTextAttribute(h, 14);   //adding colours
                }
                else if (ptr[i][j].name == '@')
                {
                    SetConsoleTextAttribute(h, 15);   //adding colours
                }
                else if (ptr[i][j].name == '#')
                {
                    SetConsoleTextAttribute(h, 15);   //adding colours
                }
                else if (ptr[i][j].name == 'E')
                {
                    SetConsoleTextAttribute(h, 2);   //adding colours
                }
                else if (ptr[i][j].name == 'S')
                {
                    SetConsoleTextAttribute(h, 2);   //adding colours
                }
                else if (ptr[i][j].name == '$')
                {
                    SetConsoleTextAttribute(h, 11);   //adding colours
                }
                else if (ptr[i][j].name == 'X')
                {
                    SetConsoleTextAttribute(h, 13);   //adding colours
                }
                else if (ptr[i][j].name == 'Y')
                {
                    SetConsoleTextAttribute(h, 6);   //adding colours
                }
                else if (ptr[i][j].name == '^')
                {
                    SetConsoleTextAttribute(h, 8);   //adding colours
                }
                cout << ptr[i][j].name << " ";
            }
            cout << endl;
        }
        SetConsoleTextAttribute(h, 15);   //black
    }
    graph** penalty(char name, graph**& a, int level)
    {
        if (name == 'S')
        {
            a[1][1].name = '@';
        }
        else if (name == 'E')
        {
            if (level == 1)
            {
                a[18][1].name = '@';

            }
            else if (level == 2)
            {
                a[28][1].name = '@';

            }
            else if (level == 3)
            {
                a[38][1].name = '@';
            }
        }
        return a;
    }
    graph** move2(char key, graph** ptr, game& g)
    {
        int a = 0;
        if (g.level == 1)  //Setting grid size according to the level number
        {
            a = 20;
        }
        else if (g.level == 2)  //Setting grid size according to the level number
        {
            a = 30;
        }
        else if (g.level == 3)   //Setting grid size according to the level number
        {
            a = 40;
        }
        else
        {
            cout << "Invalid level" << endl;   //validation
        }
        int r, c = 0;
        for (int x = 0;x < a;x++)
        {
            for (int y = 0;y < a;y++)
            {
                if (ptr[x][y].name == '@')
                {
                    r = x;
                    c = y;
                    break;
                }
            }
        }
        if (key == 'a')
        {
            if (ptr[r][c - 1].name == '$')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start
                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                //      print_bonus();
                return ptr;
            }
            if (ptr[r][c - 1].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start
                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 1);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);

                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == '#')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r][c - 1].name != '|' && ptr[r][c - 1].name != '-' && ptr[r][c - 1].name != 'X' && ptr[r][c - 1].name != 'Y')  //left
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "One ^ has been utilized " << endl;    //when each ^ will be utilized
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);

                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 'd')
        {
            if (ptr[r][c + 1].name == '#')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);
                    return ptr;
                }
            }
            if (ptr[r][c + 1].name == '$')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);

                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == 'E')
            {
                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);

                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }

            if (ptr[r][c + 1].name != '|' && ptr[r][c + 1].name != '-' && ptr[r][c + 1].name != 'X' && ptr[r][c + 1].name != 'Y')  //right
            {
                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c + 1].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 's')
        {
            if (ptr[r + 1][c].name == '#')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r + 1][c].name == '$')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);
                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }

            if (ptr[r + 1][c].name != '|' && ptr[r + 1][c].name != '-' && ptr[r + 1][c].name != 'X' && ptr[r + 1][c].name != 'Y')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }

                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 'w')
        {
            if (ptr[r - 1][c].name == '#')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    g.level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r - 1][c].name == '$')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);
                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name != '|' && ptr[r - 1][c].name != '-' && ptr[r - 1][c].name != 'X' && ptr[r - 1][c].name != 'Y')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '-';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;

                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        return ptr;
    }
    graph** move(char key, graph** ptr, game& g)
    {
        int a = 0;
        if (g.level == 1)  //Setting grid size according to the level number
        {
            a = 20;
        }
        else if (g.level == 2)  //Setting grid size according to the level number
        {
            a = 30;
        }
        else if (g.level == 3)   //Setting grid size according to the level number
        {
            a = 40;
        }
        else
        {
            cout << "Invalid level" << endl;   //validation
        }
        int r, c = 0;
        for (int x = 0;x < a;x++)
        {
            for (int y = 0;y < a;y++)
            {
                if (ptr[x][y].name == '@')
                {
                    r = x;
                    c = y;
                    break;
                }
            }
        }
        if (key == 'a')
        {
            if (ptr[r][c - 1].name == '$')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start
                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                //      print_bonus();
                return ptr;
            }
            if (ptr[r][c - 1].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start
                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 1);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);

                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }
            if (ptr[r][c - 1].name == '#')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r][c - 1].name != '|' && ptr[r][c - 1].name != '-' && ptr[r][c - 1].name != 'X' && ptr[r][c - 1].name != 'Y')  //left
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c - 1].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "One ^ has been utilized " << endl;    //when each ^ will be utilized
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);

                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 'd')
        {
            if (ptr[r][c + 1].name == '#')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);
                    return ptr;
                }
            }
            if (ptr[r][c + 1].name == '$')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);

                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == 'E')
            {
                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r][c + 1].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r][c + 1].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);

                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }

            if (ptr[r][c + 1].name != '|' && ptr[r][c + 1].name != '-' && ptr[r][c + 1].name != 'X' && ptr[r][c + 1].name != 'Y')  //right
            {
                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c + 1].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 's')
        {
            if (ptr[r + 1][c].name == '#')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    g.level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r + 1][c].name == '$')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);

                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r + 1][c].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);
                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }

            if (ptr[r + 1][c].name != '|' && ptr[r + 1][c].name != '-' && ptr[r + 1][c].name != 'X' && ptr[r + 1][c].name != 'Y')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r + 1][c].name = '@';
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;
                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }

                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        if (key == 'w')
        {
            if (ptr[r - 1][c].name == '#')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                if (level < 3)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);
                    cout << "Congratulations, Level " << level << " passed successfully." << endl;
                    level++;
                    SetConsoleTextAttribute(h, 9);
                    cout << "press 1 to continue" << endl;
                    int continu;
                    cin >> continu;
                    if (continu == 1)
                    {
                        system("cls");
                    }
                    else
                    {
                        system("cls");
                    }

                    return ptr;
                }
                else
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    g.level++;  //level increasing more then 3 for using to terminate in main
                    cout << "Congratulations, won the game" << endl;
                    SetConsoleTextAttribute(h, 15);


                    return ptr;
                }
            }
            if (ptr[r - 1][c].name == '$')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, You got bonus +2" << endl;
                SetConsoleTextAttribute(h, 15);
                g.score = g.score + 2;
                bonus_list('$', 2, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == 'S')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('S', ptr, g.level);
                bonus_list('S', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == 'E')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr = penalty('E', ptr, g.level);
                bonus_list('E', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name == '^')
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 11);
                cout << "Congratulations, Car can bear one obstacle without any penalty" << endl;
                SetConsoleTextAttribute(h, 15);
                g.protect = g.protect + 1;   //protection has been added over car to avoid penalty for one time when it will touch obstacles                
                bonus_list('^', 0, g);
                return ptr;
            }
            if (ptr[r - 1][c].name != '|' && ptr[r - 1][c].name != '-' && ptr[r - 1][c].name != 'X' && ptr[r - 1][c].name != 'Y')  //up
            {
                g.check = 0;  //when player move in correct path the check will become 0. So to lost the game it need to be at 3 again from start

                ptr[r][c].name = '.';  //removing car from previous place and placing it to the next place
                ptr[r - 1][c].name = '@';
                return ptr;
            }
            else
            {
                if (g.protect > 0)
                {
                    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                    SetConsoleTextAttribute(h, 11);

                    cout << "One ^ has been utilized " << endl;

                    g.protect = g.protect - 1;
                    if (g.protect == 0)
                    {
                        cout << "Be careful obstacle will produce damage next time" << endl;
                    }
                    SetConsoleTextAttribute(h, 15);
                }
                else
                {
                    g.check = g.check + 1;
                    if (g.check == 3)
                    {
                        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                        SetConsoleTextAttribute(h, 14);
                        cout << "You have lost the game" << endl;
                        SetConsoleTextAttribute(h, 15);
                        return NULL;
                    }
                    if (g.score - 5 >= 0)
                    {
                        g.score = g.score - 5;  //deduction of score as car is interacting with obstacles

                    }
                }
            }
        }
        return ptr;
    }
    void bonus_list(char name, int s, game& g)
    {
        if (head == NULL)
        {
            bonus* newbonus = new bonus();
            newbonus->num = g.index;
            newbonus->level = g.level;
            newbonus->score = s;
            newbonus->type = name;
            newbonus->previous = nullptr;
            newbonus->next = nullptr;
            head = newbonus;
            g.index++;
            //      cout << "HH" << endl;
        }
        else
        {
            bonus* temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            bonus* newbonus = new bonus();
            newbonus->num = g.index;
            newbonus->level = g.level;
            newbonus->score = s;
            newbonus->type = name;
            newbonus->previous = temp;
            newbonus->next = nullptr;
            temp->next = newbonus;
            g.index++;
        }
    }

    void print_bonus()
    {
        bonus* temp = head;
        if (temp == NULL)
        {
            HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
            SetConsoleTextAttribute(h, 11);

            cout << "Bonus list is empty yet" << endl;
            SetConsoleTextAttribute(h, 15);

            return;
        }
        while (temp != NULL)   //For traversing to each node and then printing the following data that is availabale at each node already
        {
            HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
            SetConsoleTextAttribute(h, 11);
            cout << "Bonus number : " << temp->num << endl;
            cout << "Bonus type : " << temp->type << endl;
            cout << "Score weightage : " << temp->score << endl;
            cout << "Availed during the level : " << temp->level << endl;
            SetConsoleTextAttribute(h, 15);
            cout << endl;
            temp = temp->next;
        }
        return;
    }
    void controls()
    {
        //Instruction about controls
        cout << "User controls \n 1- 'a' for left \n 2- 'd' for right \n 2- 's' for down \n 2- 'w' for up " << endl;
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(h, 6);
        cout << "press 1 to continue" << endl;
        int continu;
        SetConsoleTextAttribute(h, 15);

        cin >> continu;
        if (continu == 1)
        {
            system("cls");
        }
        else
        {
            system("cls");
        }

        return;
    }
    void rules_regulation()
    {
        //Instruction for each happening in the game
        cout << "1- Game have 3 different stages, and it will start from first and easiest stage" << endl;
        cout << "2- Successfully reaching at destination will lead the player to the next stage" << endl;
        cout << "3- Car route include couple of obstacles (X,Y,| , -) interaction of car with these obstacle will deduct -5 from total score " << endl;
        cout << "4- Successfully jumping from one point to other on the route will have no effect on score " << endl;
        cout << "5- Intraction of car with bonus(#) will add + 2 in total score" << endl;
        cout << "6- Consecutive 3 interactions with the obstacle will make sure that plaer has lost the game" << endl;
        cout << "7- ^ will add one layer of protection over the car which will resist the car from damage once it hits the obstacle once" << endl;
        cout << "8- E & S will took the car to the end and first line of racing track respectively" << endl;
        cout << "9- player can quit the game at any instant during the race " << endl;
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(h, 6);
        cout << "press 1 to continue" << endl;
        SetConsoleTextAttribute(h, 15);
        bool ask;
        cin >> ask;
        if (ask == 1)
        {
            system("cls");
        }
        else
        {
            system("cls");
        }
        return;
    }

    MaxHeapNode* insertIntoHeap(MaxHeapNode* node, int score)   //Making heap / Binary tree for score leader board
    {
        if (node == NULL) {
            return new MaxHeapNode(score);
        }

        if (score > node->score) {
            swap(score, node->score);
        }

        if (node->left == NULL) {
            node->left = new MaxHeapNode(score);
        }
        else if (node->right == NULL) {
            node->right = new MaxHeapNode(score);
        }
        else {
            int leftDepth = depth(node->left);
            int rightDepth = depth(node->right);

            if (leftDepth <= rightDepth) {
                node->left = insertIntoHeap(node->left, score);
            }
            else {
                node->right = insertIntoHeap(node->right, score);
            }
        }

        return node;
    }

    int depth(MaxHeapNode* node) {
        if (node == NULL)
        {
            return 0;
        }
        else {
            int leftDepth = depth(node->left);
            int rightDepth = depth(node->right);
            return max(leftDepth, rightDepth) + 1;
        }
    }
    void insertAndUpdate(int score)  //For inderting each score in the heap/Tree
    {
        root = insertIntoHeap(root, score);
        return;
    }

    int getMax()  //returning the highest value available at the tree
    {
        return (root != NULL) ? root->score : -1;  // Return -1 for an empty heap
    }
    void automatic(game& g, graph**& ptr)
    {
        ptr = g.create_grid(g);
        int check1 = 1;
        int check2 = 1;
        int l1 = 5, l2 = 3, l3 = 6;
        while (1)
        {
            if (g.level == 1 && l1 != 0)
            {
                if (l1 == 5)
                {
                    int count = 0;
                    while (count != 6)
                    {
                        g.print_grid(ptr, g, 0);
                        std::this_thread::sleep_for(std::chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);  //moving down
                        system("cls");
                        ++count;
                    }
                }
                if (l1 == 4)
                {
                    int count = 0;
                    while (count != 10)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);  //moving right
                        system("cls");
                        ++count;
                    }
                }
                if (l1 == 3)
                {
                    int count = 0;
                    while (count != 9)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);  //down
                        system("cls");
                        ++count;
                    }
                }
                if (l1 == 2)
                {
                    int count = 0;
                    while (count != 7)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);      //right
                        system("cls");
                        ++count;
                    }
                }
                if (l1 == 1)
                {
                    int count = 0;
                    while (count != 2)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);
                        system("cls");
                        ++count;
                    }
                }
                l1--;
            }
            else if (g.level == 2 && l2 != 0)
            {

                if (check1 == 1)
                {
                    cout << "I am here " << endl;
                    ptr = g.create_grid(g);
                    check1++;
                }
                //    cout << "11" << endl;
                if (l2 == 3)
                {
                    //      cout << "22" << endl;
                    int count = 0;
                    while (count != 18)
                    {
                        g.print_grid(ptr, g, 0);
                        std::this_thread::sleep_for(std::chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);  //moving down
                        system("cls");
                        ++count;
                    }
                }
                if (l2 == 2)
                {
                    int count = 0;
                    while (count != 27)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);  //moving right
                        system("cls");
                        ++count;
                    }
                }
                if (l2 == 1)
                {
                    int count = 0;
                    while (count != 9)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);  //down
                        system("cls");
                        ++count;
                    }
                }
                l2--;
            }
            else if (g.level == 3 && l3 != 0)
            {
                if (check2 == 1)
                {
                    ptr = g.create_grid(g);
                    check2++;
                }
                if (l3 == 6)
                {
                    int count = 0;
                    while (count != 9)
                    {
                        g.print_grid(ptr, g, 0);
                        std::this_thread::sleep_for(std::chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);  //moving down
                        system("cls");
                        ++count;
                    }
                }
                if (l3 == 5)
                {
                    int count = 0;
                    while (count != 19)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);  //moving right
                        system("cls");
                        ++count;
                    }
                }
                if (l3 == 4)
                {
                    int count = 0;
                    while (count != 24)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);  //down
                        system("cls");
                        ++count;
                    }
                }
                if (l3 == 3)
                {
                    int count = 0;
                    while (count != 17)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);      //right
                        system("cls");
                        ++count;
                    }
                }
                if (l3 == 2)
                {
                    int count = 0;
                    while (count != 4)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('d', ptr, g);
                        system("cls");
                        ++count;
                    }
                }
                if (l3 == 1)
                {
                    int count = 0;
                    while (count != 1)
                    {
                        g.print_grid(ptr, g, 0);
                        this_thread::sleep_for(chrono::seconds(1));
                        ptr = g.move2('s', ptr, g);
                        system("cls");
                        ++count;
                    }
                }
                l3--;
            }
            else if (l1 == 0 && l2 == 0 && l3 == 0)
            {
                //           cout << "Break" << endl;
                break;
            }
        }
        return;
    }
};
int game::bost = 0;
int game::index = 1;  //for linked list of all the bonuses
int game::protect = 0;  //checking either layer of protection is present on car or no